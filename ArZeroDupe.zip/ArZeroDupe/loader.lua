-- loader.lua
-- Jalankan ini di executor

loadstring(game:HttpGet("https://raw.githubusercontent.com/USERNAME/REPO/main/Chilli.lua"))()
